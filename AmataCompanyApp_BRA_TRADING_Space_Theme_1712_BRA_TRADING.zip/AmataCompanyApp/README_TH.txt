Amata Company Directory - Android project

โปรเจกต์นี้บรรจุเว็บแอปฐานข้อมูลบริษัทไว้ภายในแอป Android ด้วย WebView
ใช้งานข้อมูลที่ฝังอยู่ในไฟล์ได้แบบออฟไลน์ ไม่ต้องเชื่อมต่ออินเทอร์เน็ตสำหรับการค้นหาข้อมูล

วิธีสร้างไฟล์ APK ด้วย Android Studio:
1. ติดตั้ง Android Studio และ Android SDK Platform 35
2. แตกไฟล์ ZIP นี้
3. เปิดโฟลเดอร์ AmataCompanyApp ใน Android Studio
4. รอ Gradle Sync ให้เสร็จ
5. เลือก Build > Build Bundle(s) / APK(s) > Build APK(s)
6. ไฟล์ APK จะอยู่ที่ app/build/outputs/apk/debug/app-debug.apk
7. ส่งไฟล์ APK ไปยังมือถือ Android แล้วแตะเพื่อติดตั้ง (อาจต้องอนุญาตติดตั้งจากแหล่งนี้)

หมายเหตุ: ต้องมี Android SDK และการเชื่อมต่ออินเทอร์เน็ตครั้งแรกเพื่อดาวน์โหลด Gradle/Android Gradle Plugin
ชื่อแอป: Amata Company Directory
Application ID: com.amata.directory
Minimum Android: Android 6.0 (API 23)
