AmataCompanyDirectory2 สำหรับ Windows 11

ไฟล์นี้เป็นโปรเจกต์สำหรับสร้างตัวติดตั้ง Windows .EXE โดยใช้ข้อมูลหน้าเว็บชุดเดียวกับแอป Android

สิ่งที่อยู่ใน ZIP:
- windows-app/index.html : ฐานข้อมูลบริษัท
- windows-app/main.js : ตัวเปิดโปรแกรม Windows
- windows-app/package.json : ค่าการสร้างโปรแกรม
- build-windows-exe.yml : Workflow สำหรับ GitHub Actions

วิธีใช้:
1. อัปโหลด ZIP นี้ไว้ที่ root ของ GitHub repository ชื่อ AmataCompanyDirectory2
   โดยใช้ชื่อไฟล์ AmataCompanyDirectory2_Windows11_Project.zip
2. ใน GitHub ให้สร้างไฟล์ใหม่ชื่อ .github/workflows/build-windows-exe.yml
   แล้วคัดลอกเนื้อหาจากไฟล์ build-windows-exe.yml ใน ZIP ไปวางและ Commit
3. เปิดแท็บ Actions > Build Amata Windows EXE > Run workflow
4. เมื่อทำงานสำเร็จ เปิดรายการ run แล้วดาวน์โหลด Artifact ชื่อ
   AmataCompanyDirectory2-Windows11-Setup
5. แตก ZIP ที่ดาวน์โหลด แล้วเปิดไฟล์ Setup .exe บน Windows 11

หมายเหตุ:
- ต้องใช้ Windows 11 แบบ 64-bit สำหรับตัวติดตั้งที่ตั้งค่าไว้นี้
- ไฟล์ EXE จะถูกสร้างโดย GitHub Actions บนเครื่อง Windows ของ GitHub
- ฐานข้อมูลทำงานจากไฟล์ในเครื่อง ไม่จำเป็นต้องมี Android Studio
